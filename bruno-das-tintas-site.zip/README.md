# Bruno das Tintas — site

MVP estático do site da Bruno das Tintas. Catálogo, carrinho e pedido caindo no
WhatsApp da loja. Sem build, sem dependência: é HTML, CSS e JS puro.

## ⚠️ Antes de apontar o domínio

O projeto está configurado para **homologação**: o site é publicado, mas fica
invisível para o Google. Isso é de propósito — se o Google indexar o endereço
`.vercel.app`, ele passa a aparecer nas buscas por "Bruno das Tintas" e vira
conteúdo duplicado quando o domínio real entrar.

Checklist para virar produção (nesta ordem):

- [ ] Remover o bloco `X-Robots-Tag` do `vercel.json`
- [ ] Trocar o `robots.txt` pela versão de produção (está comentada dentro do arquivo)
- [ ] Trocar `https://www.brunodastintas.com.br` pelo domínio real em `index.html`
      (canonical, `og:url` e os dois blocos do JSON-LD) e no `sitemap.xml`
- [ ] Tirar a faixa preta de MVP do topo do `index.html` (`<div class="mvp-bar">`)
- [ ] Conferir preços, produtos e frete com a loja
- [ ] Testar o pedido ponta a ponta num celular de verdade, nas duas lojas
- [ ] Só então apontar o domínio

## Estrutura

```
index.html              estrutura da página + JSON-LD das duas lojas
robots.txt / sitemap.xml  trocar o domínio quando sair do .vercel.app
assets/css/styles.css   design system e layout
assets/js/dados.js      ← catálogo, marcas, setores e as duas lojas
assets/js/app.js        catálogo, carrinho e checkout
assets/img/             logo, banner e fotos de produto (webp, fundo azul)
assets/img/marcas/      logos das marcas (webp, fundo transparente)
vercel.json             cache dos assets
```

**Para mexer no catálogo, só `dados.js` importa.** Produto, marca, setor, preço,
WhatsApp e frete estão todos lá. `app.js` não precisa ser tocado para isso.

## Antes de publicar no domínio

Trocar `https://www.brunodastintas.com.br` pelo domínio real em três lugares:
`index.html` (canonical, og:url e JSON-LD), `robots.txt` e `sitemap.xml`.

## Deploy na Vercel

Pelo painel, sem terminal:

1. Suba a pasta num repositório do GitHub
2. Vercel → Add New → Project → importe o repositório
3. Framework Preset: **Other**. Build Command e Output Directory ficam vazios
4. Deploy

Pelo terminal:

```bash
npm i -g vercel
cd bruno-das-tintas-site
vercel          # preview
vercel --prod   # produção
```

Domínio próprio só depois do checklist de lançamento — até lá roda no link
`.vercel.app`.

## Regras do catálogo

- **Produto só entra com foto.** Sem foto, fora do ar.
- **Foto sempre com fundo azul** (`#0B4DBF`), produto recortado e centralizado,
  quadrada, exportada em webp.
- **Marca só entra se o cliente confirmou** que trabalha com ela.
- Setor sem nenhum produto não aparece no site. Hoje **Madeira** e
  **Impermeabilizantes** estão nessa situação — voltam sozinhos assim que
  entrar um produto com aquele `set`.

## As duas lojas

Cada unidade tem WhatsApp e link de mapa próprios, em `UNIDADES` no `dados.js`.
O site roteia sozinho:

- Retirada em Araruama → WhatsApp de Araruama
- Retirada em Iguaba → WhatsApp de Iguaba
- Entrega → o cliente marca qual loja fica mais perto, e o pedido vai para ela
- Botões de "falar com a loja" abrem um seletor com as duas

O campo `maps` hoje é uma busca por endereço. O ideal é trocar pelo link curto do
perfil de cada loja no Google Business (Compartilhar → Copiar link), que abre a
ficha com foto, avaliação e rota.

## Como funciona o pedido

O checkout é um passo a passo de três telas, para não empilhar tudo num
formulário só:

1. **Dados** — nome, WhatsApp e forma de recebimento. Escolhendo entrega,
   aparece o endereço e a cidade de destino
2. **Pagamento** — PIX, dinheiro, débito ou crédito. PIX e dinheiro descontam 5%
   ao vivo no resumo; no crédito abre um seletor de em quantas vezes, com o valor
   de cada parcela calculado sobre o total
3. **Enviar** — cor da tinta, observação, resumo final e o botão que abre a
   conversa **da loja que vai atender**, com a nota formatada: nome, telefone,
   itens, quantidade, cor, forma de pagamento e total já com desconto

Voltar entre os passos não perde o que já foi preenchido.

**Entrega e frete.** `DESTINOS` no `dados.js` define para onde vai e quanto custa:
Araruama e Iguaba são frete grátis e já definem qual loja atende; outras cidades
da Região dos Lagos ficam como "a combinar" e aí o cliente escolhe a loja.

**Entrega no mesmo dia.** `LOJA.corteEntregaHoje` está `null` de propósito. Com um
horário real ali (`'15:00'`), o site passa a mostrar quanto falta para o corte e
avisa quando já passou. Sem o horário confirmado pela loja, nenhuma promessa de
prazo aparece.

**Parcelamento.** `LOJA.parcelas` é o teto de vezes e `LOJA.parcelaMinima` o valor
mínimo por parcela (`null` = sem mínimo, que é o caso hoje). `LOJA.semJuros` fica
`null` de propósito: enquanto a loja não confirmar se o parcelado tem juros, o
site mostra só o valor da parcela e diz que a condição final é confirmada no
WhatsApp — nada de prometer "sem juros" por conta própria.

**Upsell.** `UPSELL` no `dados.js` liga cada setor aos itens que costumam faltar
junto. Quem põe tinta no carrinho vê kit de pintura e lona sugeridos dentro da
gaveta, com botão de adicionar. Item que já está no carrinho não é sugerido.

Não existe pagamento dentro do site. O site registra a escolha e a loja combina
o recebimento no WhatsApp — que é como a Bruno já trabalha hoje.

O desconto de 5% fica em `LOJA.descontoAvista` e as formas em `PAGAMENTOS`,
ambos no `dados.js`.

## O que ainda não é real

| Item | Situação | O que resolve |
|---|---|---|
| Pagamento online | Não existe — é combinado no WhatsApp | Integrar PagSeguro (a maquininha que a loja já usa) quando fizer sentido |
| Envio do pedido | Abre o WhatsApp do cliente, ele aperta enviar | API de WhatsApp para cair sozinho na loja |
| Preços | De exemplo | Tabela do cliente |
| Catálogo | 7 produtos | Fotos de Qualyvinil, Suvinil e Sinteplast |
| Admin | Não existe | Migração para Next.js + Supabase |

## Migração para Next.js

Quando o escopo fechar, `dados.js` vira as tabelas `produtos`, `marcas` e
`setores` no Supabase, e o cliente passa a cadastrar pelo admin. O CSS e a
estrutura de tela aproveitam direto.

---
Lone Mídia
